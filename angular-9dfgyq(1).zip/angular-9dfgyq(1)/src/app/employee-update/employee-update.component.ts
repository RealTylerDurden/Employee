import { Employee } from '../employee';
import { Component, OnInit, Input } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { EmployeeListComponent } from '../employee-list/employee-list.component';
import { Router, ActivatedRoute } from '@angular/router';
import{FormsModule} from '@angular/forms';

@Component({
  selector: 'app-employee-update',
  templateUrl: './employee-update.component.html',
  styleUrls: ['./employee-update.component.css']
})
export class EmployeeUpdateComponent implements OnInit {

  id: number;
  employee:object={};
  employeeObj:object={};

  constructor(private route: ActivatedRoute,private router: Router,
    private employeeService: EmployeeService) { }

  ngOnInit()
  {
   
   this.route.params.subscribe(params=>{
     this.id = +params['id'];
     console.log("update component-->"+this.id);
     this.employeeService.getEmployee(this.id).subscribe(employee => this.employee = employee);
   });
    }
    


  updateEmployee(employee:Employee) {
    console.log(employee);
    this.employeeObj={
         "id" : this.id,
         "name":employee.name,
         "location":employee.location,
        "emailid":employee.emailid,
        "mobileno":employee.mobileno
        };
    this.employeeService.updateEmployee(this.id,this.employeeObj).subscribe(data => console.log(data),error => console.log(error));
    this.gotoList();
  }
/*
  onSubmit(employee:Employee) {
    this.updateEmployee(employee);    
  }*/

  gotoList() {
    this.router.navigate(['/employees']);
  }
}


