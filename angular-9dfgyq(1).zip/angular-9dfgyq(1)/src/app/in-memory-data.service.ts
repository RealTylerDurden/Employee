import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Employee } from './employee';
@Injectable()
export class InMemoryDataService {
createDb() {
    const employees = [
      
{id: 1,name: 'Ram', location: 'banglore',emailid: 'ram@mail.com',mobileno:9867512345}
,{id: 2,name: 'Raj', location: 'chennai',emailid: 'raj@mail.com',mobileno:7867534521}

    ];
    return {employees};
}
 genId(employees: Employee[]): number {
    return employees.length > 0 ? Math.max(...employees.map(employee => employee.id)) + 1 : 1;
  }
}