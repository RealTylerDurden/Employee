export interface Employee {
  id:number;
  name:string;
  location:string;
  emailid:string;
  mobileno:number;
  

}