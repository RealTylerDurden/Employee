import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router,ActivatedRoute } from '@angular/router'
import{FormsModule} from '@angular/forms';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {
employees:Employee[];
  constructor(private employeeservice:EmployeeService,private route: ActivatedRoute,private router: Router) { }
ngOnInit() {
    this.employeeservice.getEmployees()
    .subscribe(employees => this.employees = employees);
  }
  add(name: string,location:String,emailid:string,mobileno:number): void {
    name = name.trim();
     location = location.trim();
      emailid = emailid.trim();
   
    if (!name && !location && !emailid && !mobileno) { return; }
    this.employeeservice.addEmployee({ name ,location,emailid,mobileno}as Employee)
      .subscribe(()=>{
        this.gotoList();
    });
      
  }
  gotoList() {
    this.router.navigate(['/employees']);
  }
}