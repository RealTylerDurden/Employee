import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import { Router} from '@angular/router';
import{Validators} from '@angular/forms';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
employees:Employee[];
  constructor(private employeeservice:EmployeeService,private router: Router) { }

  ngOnInit() {
        this.getEmployees();
  }
 getEmployees(): void {
    this.employeeservice.getEmployees()
    .subscribe(employees => this.employees = employees);
  }
   delete(employee:number): void {
    this.employees = this.employees.filter(h => h !== employee);
    this.employeeservice.deleteEmployee(employee).subscribe(()=>{
      console.log(employee);
      this.getEmployees();
    });
   }
   update(id:number):void
   {
     console.log(id);
      this.router.navigate(['editEmployee',id]);
   }
   }