import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import{ReactiveFormsModule} from '@angular/forms';

import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { EmployeeDeleteComponent } from './employee-delete/employee-delete.component';
import { EmployeeUpdateComponent } from './employee-update/employee-update.component';
import { EmployeeService } from './employee.service';
import { InMemoryDataService } from './in-memory-data.service';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';
import { AppRoutingModule }     from './app-routing.module';
import { EmployeeFilterPipe } from './employee-list/employee-filter.pipe';

@NgModule({
 imports:      [ BrowserModule, FormsModule, AppRoutingModule,
    HttpClientModule,ReactiveFormsModule,
    HttpClientInMemoryWebApiModule.forRoot(
      InMemoryDataService, { dataEncapsulation: false }
    )
 ],
  declarations: [ AppComponent, HelloComponent, EmployeeListComponent, EmployeeAddComponent, EmployeeDeleteComponent, EmployeeUpdateComponent, EmployeeDetailComponent, EmployeeFilterPipe ],
  bootstrap:    [ AppComponent ],
  providers: [EmployeeService, InMemoryDataService]
})
export class AppModule { }
