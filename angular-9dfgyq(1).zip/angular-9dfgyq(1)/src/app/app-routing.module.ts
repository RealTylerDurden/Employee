import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { EmployeeDeleteComponent } from './employee-delete/employee-delete.component';
import { EmployeeUpdateComponent } from './employee-update/employee-update.component';
import { EmployeeDetailComponent } from './employee-detail/employee-detail.component';

const routes: Routes = [
   {path: 'employees', component: EmployeeListComponent},
  {path: 'detail/:id', component: EmployeeDetailComponent},
   {path: 'addEmployee', component: EmployeeAddComponent},
   {path: 'delete/:id', component: EmployeeDeleteComponent},
   {path:'editEmployee/:id',component:EmployeeUpdateComponent}
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
